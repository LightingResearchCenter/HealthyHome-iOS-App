/*
 * blackbox_initialize.c
 *
 * Code generation for function 'blackbox_initialize'
 *
 * C source code generated on: Mon Jul 13 11:40:53 2015
 *
 */

/* Include files */
#include "blackbox.h"
#include "blackbox_initialize.h"

/* Function Definitions */
void blackbox_initialize(void)
{
}

/* End of code generation (blackbox_initialize.c) */
