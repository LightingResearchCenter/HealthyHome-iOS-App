/*
 * bedWakeTimes2TargetPhase.h
 *
 * Code generation for function 'bedWakeTimes2TargetPhase'
 *
 * C source code generated on: Mon Jul 13 11:40:53 2015
 *
 */

#ifndef __BEDWAKETIMES2TARGETPHASE_H__
#define __BEDWAKETIMES2TARGETPHASE_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "blackbox_types.h"

/* Function Declarations */
extern double bedWakeTimes2TargetPhase(double bedTime, double wakeTime);
#endif
/* End of code generation (bedWakeTimes2TargetPhase.h) */
