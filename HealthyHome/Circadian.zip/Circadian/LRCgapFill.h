/*
 * LRCgapFill.h
 *
 * Code generation for function 'LRCgapFill'
 *
 * C source code generated on: Mon Jul 13 11:40:53 2015
 *
 */

#ifndef __LRCGAPFILL_H__
#define __LRCGAPFILL_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "blackbox_types.h"

/* Function Declarations */
extern void LRCgapFill(const emxArray_real_T *timeUTC, const emxArray_real_T *cs, emxArray_real_T *newTimeUTC, emxArray_real_T *newCs);
#endif
/* End of code generation (LRCgapFill.h) */
