/*
 * LRCtruncate_activityReading.h
 *
 * Code generation for function 'LRCtruncate_activityReading'
 *
 * C source code generated on: Mon Jul 13 11:40:53 2015
 *
 */

#ifndef __LRCTRUNCATE_ACTIVITYREADING_H__
#define __LRCTRUNCATE_ACTIVITYREADING_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "blackbox_types.h"

/* Function Declarations */
extern void LRCtruncate_activityReading(const emxArray_real_T *acyivityReading_timeUTC, const emxArray_real_T *acyivityReading_timeOffset, const emxArray_real_T *acyivityReading_activityIndex, const emxArray_real_T *acyivityReading_activityCount, emxArray_real_T *activityReadingTrunc_timeUTC, emxArray_real_T *activityReadingTrunc_timeOffset, emxArray_real_T *c_activityReadingTrunc_activity, emxArray_real_T *d_activityReadingTrunc_activity);
#endif
/* End of code generation (LRCtruncate_activityReading.h) */
