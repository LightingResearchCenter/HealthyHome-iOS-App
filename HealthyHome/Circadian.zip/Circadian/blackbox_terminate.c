/*
 * blackbox_terminate.c
 *
 * Code generation for function 'blackbox_terminate'
 *
 * C source code generated on: Mon Jul 13 11:40:53 2015
 *
 */

/* Include files */
#include "blackbox.h"
#include "blackbox_terminate.h"

/* Function Definitions */
void blackbox_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (blackbox_terminate.c) */
