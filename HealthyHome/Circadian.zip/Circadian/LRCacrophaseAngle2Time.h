/*
 * LRCacrophaseAngle2Time.h
 *
 * Code generation for function 'LRCacrophaseAngle2Time'
 *
 * C source code generated on: Mon Jul 13 11:40:53 2015
 *
 */

#ifndef __LRCACROPHASEANGLE2TIME_H__
#define __LRCACROPHASEANGLE2TIME_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "blackbox_types.h"

/* Function Declarations */
extern double LRCacrophaseAngle2Time(double acrophaseAngle);
#endif
/* End of code generation (LRCacrophaseAngle2Time.h) */
