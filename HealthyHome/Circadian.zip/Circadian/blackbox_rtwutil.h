/*
 * blackbox_rtwutil.h
 *
 * Code generation for function 'blackbox_rtwutil'
 *
 * C source code generated on: Mon Jul 13 11:40:53 2015
 *
 */

#ifndef __BLACKBOX_RTWUTIL_H__
#define __BLACKBOX_RTWUTIL_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "blackbox_types.h"

/* Function Declarations */
extern double rt_roundd(double u);
#endif
/* End of code generation (blackbox_rtwutil.h) */
